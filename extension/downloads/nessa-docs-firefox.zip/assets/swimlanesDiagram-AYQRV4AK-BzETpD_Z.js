import{r as e,t}from"./chunk-NQOKRVIF-D-fHrxMp.js";import"./chunk-XXDRQBXY-BS5T21hu.js";import"./chunk-VQ5W62QI-BTg-Rebp.js";import"./mermaid.core-Dk1fyDSX.js";import"./chunk-55XCU76K-Dd98PpOd.js";import"./chunk-HNE4Q36P-Bog093CA.js";import"./chunk-WQQL4CDK-q7SGi1Fe.js";import"./chunk-ZAUX2LTX-CoX8VQ0o.js";import"./chunk-HAGFOTED-DAOEBOJR.js";import"./chunk-UHW7PFBP-B5iDCSTx.js";import"./chunk-AQDTSKZB-BmmE_o3V.js";import"./chunk-YZO67HFG-CzYK3Cz6.js";import"./chunk-7S6XSTFO-CeSj19EV.js";import"./chunk-DSNLSHJZ-D0UMBilO.js";import"./src-DUsG9yDj.js";import{n}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";var r=t({styles:n(t=>`${e(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};