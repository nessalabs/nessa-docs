import{r as e,t}from"./chunk-NQOKRVIF-DP4IkKrW.js";import"./chunk-XXDRQBXY-BS5T21hu.js";import"./chunk-VQ5W62QI-DtqyiiPM.js";import"./mermaid.core-V8mrbeCG.js";import"./chunk-55XCU76K-DE_GczuN.js";import"./chunk-HNE4Q36P-BbtEBhCi.js";import"./chunk-WQQL4CDK-DjyMl8J6.js";import"./chunk-ZAUX2LTX-D5hBoBKx.js";import"./chunk-HAGFOTED-DohqoqmB.js";import"./chunk-UHW7PFBP-CZL3bKvs.js";import"./chunk-AQDTSKZB-By9lTPm7.js";import"./chunk-YZO67HFG-ptCWqOYa.js";import"./chunk-7S6XSTFO-B2WQeDDV.js";import"./chunk-DSNLSHJZ-DckRW5Ur.js";import"./src-DUsG9yDj.js";import{n}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";var r=t({styles:n(t=>`${e(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};