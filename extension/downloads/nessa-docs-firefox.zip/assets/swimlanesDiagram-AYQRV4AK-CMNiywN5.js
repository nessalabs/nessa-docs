import{r as e,t}from"./chunk-NQOKRVIF-BN_XNmb3.js";import"./chunk-XXDRQBXY-BS5T21hu.js";import"./chunk-VQ5W62QI-BUOussTU.js";import"./mermaid.core-ecOc2XT9.js";import"./chunk-55XCU76K-DNnZZmea.js";import"./chunk-HNE4Q36P-B4M6f3oU.js";import"./chunk-WQQL4CDK-DFdajX14.js";import"./chunk-ZAUX2LTX-BQ1XpINv.js";import"./chunk-HAGFOTED-k4bwYZk7.js";import"./chunk-UHW7PFBP-PvPut8IM.js";import"./chunk-AQDTSKZB-B5iRBHIu.js";import"./chunk-YZO67HFG-Di88EBPM.js";import"./chunk-7S6XSTFO-DGFjyUrl.js";import"./chunk-DSNLSHJZ-BPVXdd8n.js";import"./src-DUsG9yDj.js";import{n}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";var r=t({styles:n(t=>`${e(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};