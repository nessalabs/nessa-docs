import{r as e,t}from"./chunk-NQOKRVIF-BptVMFBD.js";import"./chunk-XXDRQBXY-BS5T21hu.js";import"./chunk-VQ5W62QI-BJJcSC3w.js";import"./mermaid.core-Dy0BKHN6.js";import"./chunk-55XCU76K-DpCalwYT.js";import"./chunk-HNE4Q36P-SRKKEWsj.js";import"./chunk-WQQL4CDK-CpuYOs1W.js";import"./chunk-ZAUX2LTX-DFaadQoW.js";import"./chunk-HAGFOTED-BnodTAtQ.js";import"./chunk-UHW7PFBP-mfqyvVVx.js";import"./chunk-AQDTSKZB-De34pWxF.js";import"./chunk-YZO67HFG-HoAcmKD9.js";import"./chunk-7S6XSTFO-DnMNtQ0r.js";import"./chunk-DSNLSHJZ-CRprF8dJ.js";import"./src-DUsG9yDj.js";import{n}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";var r=t({styles:n(t=>`${e(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};