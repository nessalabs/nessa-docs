import{r as e,t}from"./chunk-NQOKRVIF-BuzBwE5Z.js";import"./chunk-XXDRQBXY-BS5T21hu.js";import"./chunk-VQ5W62QI-DlKrgzv_.js";import"./mermaid.core-DC-1UPWd.js";import"./chunk-55XCU76K-hzIYZMPR.js";import"./chunk-HNE4Q36P-B2yGkNA_.js";import"./chunk-WQQL4CDK-DxHGSRo4.js";import"./chunk-ZAUX2LTX-DYAu6ixt.js";import"./chunk-HAGFOTED-DrajXHlL.js";import"./chunk-UHW7PFBP-Bx76wYzh.js";import"./chunk-AQDTSKZB-D0y5GS0r.js";import"./chunk-YZO67HFG-DGPbbagM.js";import"./chunk-7S6XSTFO-DeOzDX0o.js";import"./chunk-DSNLSHJZ-Bs17snHW.js";import"./src-DUsG9yDj.js";import{n}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";var r=t({styles:n(t=>`${e(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};