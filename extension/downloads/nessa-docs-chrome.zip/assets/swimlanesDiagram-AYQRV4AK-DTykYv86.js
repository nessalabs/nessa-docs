import{r as e,t}from"./chunk-NQOKRVIF-DQhNWPNc.js";import"./chunk-XXDRQBXY-BS5T21hu.js";import"./chunk-VQ5W62QI-Fm32TNjj.js";import"./mermaid.core-BbNpHX-d.js";import"./chunk-55XCU76K-DxZMU0B4.js";import"./chunk-HNE4Q36P-BwufNFNJ.js";import"./chunk-WQQL4CDK-DyA-R-J9.js";import"./chunk-ZAUX2LTX-CDSklhik.js";import"./chunk-HAGFOTED-DsxKf7YQ.js";import"./chunk-UHW7PFBP-DkevLPsC.js";import"./chunk-AQDTSKZB-o1s_CRDj.js";import"./chunk-YZO67HFG-Bb5g9Kqx.js";import"./chunk-7S6XSTFO-XLsiNmZo.js";import"./chunk-DSNLSHJZ-B7_yb9Tx.js";import"./src-DUsG9yDj.js";import{n}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";var r=t({styles:n(t=>`${e(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};